#include <stdio.h>

extern FILE *yyin;
int yyparse();

int main(int argc, char *argv[]){

    if(argc < 2){
        printf("Uso: ./calc archivo.txt\n");
        return 1;
    }

    yyin = fopen(argv[1],"r");

    if(!yyin){
        printf("No se pudo abrir el archivo\n");
        return 1;
    }

    yyparse();

    fclose(yyin);

    return 0;
}
