%{
#include <stdio.h>
#include <math.h>

double newton(double x);

int yylex(void);
int yyerror(const char *s);

%}

%union{
    double num;
}

%token SQRT EOL
%token <num> NUMBER

%%

input:
      | input line
      ;

line:
      SQRT NUMBER EOL { printf("sqrt(%lf) = %lf\n", $2, newton($2)); }
      ;

%%

double newton(double x){

    double guess = x/2.0;
    double eps = 0.000001;

    while(fabs(guess*guess - x) > eps){
        guess = (guess + x/guess)/2.0;
    }

    return guess;
}

int yyerror(const char *s){
    printf("Error de sintaxis\n");
    return 0;
}
