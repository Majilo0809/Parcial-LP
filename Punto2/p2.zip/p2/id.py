import sys


def afd_id(cadena):

    estado = 0

    for c in cadena:

        # estado inicial
        if estado == 0:
            if c.isalpha():
                estado = 1
            else:
                return "NO ACEPTA"

        # estado de lectura
        elif estado == 1:
            if c.isalpha() or c.isdigit():
                estado = 1
            else:
                return "NO ACEPTA"

    if estado == 1:
        return "ACEPTA"
    else:
        return "NO ACEPTA"


def leer_archivo(nombre_archivo):

    try:
        with open(nombre_archivo, "r") as archivo:

            for linea in archivo:

                cadena = linea.strip()

                if cadena != "":
                    resultado = afd_id(cadena)
                    print(cadena, ":", resultado)

    except FileNotFoundError:
        print("Error: el archivo no existe")


def main():

    if len(sys.argv) != 2:
        print("Uso correcto:")
        print("python id.py archivo.txt")
        return

    archivo = sys.argv[1]

    leer_archivo(archivo)


if __name__ == "__main__":
    main()
