def afd_ajedrez(cadena):

    estado = 0
    i = 0

    piezas = "pkqrbn"

    while i < len(cadena):

        c = cadena[i]

        if estado == 0:
            if c in piezas:
                estado = 1
            else:
                return "NO ACEPTA"

        elif estado == 1:
            if c in piezas:
                estado = 1

            elif c == '-':
                if i + 1 < len(cadena) and cadena[i+1] == '>':
                    estado = 2
                    i += 1
                else:
                    return "NO ACEPTA"

            elif c == 'x':
                estado = 2

            else:
                return "NO ACEPTA"

        elif estado == 2:
            if c in piezas:
                estado = 3
            else:
                return "NO ACEPTA"

        elif estado == 3:
            if c.isalnum():
                estado = 4
            else:
                return "NO ACEPTA"

        i += 1

    if estado == 4:
        return "ACEPTA"
    else:
        return "NO ACEPTA"


pruebas = [
    "p->k4",
    "p->K4",
    "holaa",
    "kbpxqn",
    "n->e5",
    "r->c3",
    "r->b3",
    "0809"

]

for p in pruebas:
    print(p, ":", afd_ajedrez(p))
