import Data.Time.Clock

gcdEuclides :: Int -> Int -> Int
gcdEuclides a 0 = a
gcdEuclides a b = gcdEuclides b (a `mod` b)

main :: IO ()
main = do
    let a = 123456789
    let b = 987654321

    start <- getCurrentTime

    let result = gcdEuclides a b

    end <- getCurrentTime

    print ("GCD(" ++ show a ++ "," ++ show b ++ ") = " ++ show result)
    print ("Tiempo Haskell: " ++ show (diffUTCTime end start))
