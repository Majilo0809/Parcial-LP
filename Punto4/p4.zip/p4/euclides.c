#include <stdio.h>
#include <time.h>

int gcd(int a, int b){

    while(b != 0){
        int temp = b;
        b = a % b;
        a = temp;
    }

    return a;
}

int main(){

    int a = 123456789;
    int b = 987654321;

    clock_t inicio = clock();

    int resultado = gcd(a,b);

    clock_t fin = clock();

    double tiempo = (double)(fin - inicio) / CLOCKS_PER_SEC;

    printf("GCD(%d,%d) = %d\n", a, b, resultado);
    printf("Tiempo C: %f segundos\n", tiempo);

    return 0;
}
