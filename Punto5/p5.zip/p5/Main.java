import java.io.*;

public class Main {

    public static double factorial(int n) {
        double f = 1;
        for(int i = 1; i <= n; i++){
            f *= i;
        }
        return f;
    }

    public static double maclaurin(double x, int n){

        double suma = 0;

        for(int i = 0; i < n; i++){
            suma += Math.pow(x,i) / factorial(i);
        }

        return suma;
    }

    public static void main(String[] args) throws Exception {

        BufferedReader br = new BufferedReader(new FileReader("entrada.txt"));

        String linea;

        while((linea = br.readLine()) != null){

            if(linea.trim().isEmpty()){
                continue;
            }

            linea = linea.replaceAll("\\s", "");

            linea = linea.replace("exp(", "");
            linea = linea.replace(")", "");

            String[] partes = linea.split(",");

            double x = Double.parseDouble(partes[0]);
            int n = Integer.parseInt(partes[1]);

            double resultado = maclaurin(x,n);

            System.out.println("Resultado aproximado de e^" + x + " = " + resultado);
        }

        br.close();
    }
}
